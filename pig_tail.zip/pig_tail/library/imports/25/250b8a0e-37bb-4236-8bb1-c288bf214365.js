"use strict";
cc._RF.push(module, '250b8oON7tCNouxwoi/IUNl', 'begin');
// Script/begin.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        begin1: cc.Button

    },
    // onLoad () {},

    start: function start() {
        this.begin1.node.on('click', this.callback1, this);
    },

    callback1: function callback1(button1) {
        cc.director.loadScene("lndex");
    }

    // update (dt) {},
});

cc._RF.pop();