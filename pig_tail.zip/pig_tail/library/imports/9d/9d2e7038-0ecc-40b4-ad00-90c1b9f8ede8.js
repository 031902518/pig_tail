"use strict";
cc._RF.push(module, '9d2e7A4DsxAtK0AkMG5+O3o', 'over');
// Script/over.js

"use strict";

var _mopai = require("./mopai.js");

cc.Class({
    extends: cc.Component,

    properties: {
        result1: cc.Label,
        result2: cc.Label,
        result: cc.Label,
        ReturnMainMenu: cc.Button
    },

    onLoad: function onLoad() {},
    start: function start() {
        //输出结果
        this.result1.string = "Player1:" + _mopai.sum1;
        this.result2.string = "Player2:" + _mopai.sum2;
        if (_mopai.sum1 > _mopai.sum2) {
            this.result.string = "Player2 胜利";
        } else if (_mopai.sum2 > _mopai.sum1) {
            this.result.string = "Player1 胜利";
        } else {
            this.result.string = "平局";
        }
        //返回按钮
        this.ReturnMainMenu.node.on('click', this.callback1, this);
    },

    callback1: function callback1(button1) {
        cc.director.loadScene("initialization");
    }

    // update (dt) {},
});

cc._RF.pop();