(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/begin.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '250b8oON7tCNouxwoi/IUNl', 'begin', __filename);
// Script/begin.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        begin1: cc.Button

    },
    // onLoad () {},

    start: function start() {
        this.begin1.node.on('click', this.callback1, this);
    },

    callback1: function callback1(button1) {
        cc.director.loadScene("lndex");
    }

    // update (dt) {},
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=begin.js.map
        